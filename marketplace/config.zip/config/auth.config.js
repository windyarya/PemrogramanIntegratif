module.exports = {
    secret: "ayolaundry-secret-key"
};